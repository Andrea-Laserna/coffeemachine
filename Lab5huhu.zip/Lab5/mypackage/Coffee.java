package mypackage;

public abstract class Coffee {
    protected int waterCost;
    protected int milkCost;
    protected int beansCost;
    protected double moneyCost;

    public Coffee(int waterCost, int milkCost, int beansCost, double moneyCost) {
        this.waterCost = waterCost;
        this.milkCost = milkCost;
        this.beansCost = beansCost;
        this.moneyCost = moneyCost;
    }

    public abstract String getCoffeeName();

    public int getWaterCost() {
        return waterCost;
    }

    public int getMilkCost() {
        return milkCost;
    }

    public int getBeansCost() {
        return beansCost;
    }

    public double getMoneyCost() {
        return moneyCost;
    }
}
