package mypackage;

public class ResourceManager {
    private int water;
    private int milk;
    private int beans;

    public ResourceManager(int water, int milk, int beans) {
        this.water = water;
        this.milk = milk;
        this.beans = beans;
    }

    public int getWater(){
        return water;
    }

    public int getMilk(){
        return milk;
    }

    public int getBeans(){
        return beans;
    }

    public boolean checkResources(int waterNeeded, int milkNeeded, int beansNeeded){
        return (water >= waterNeeded && milk >= milkNeeded && beans >= beansNeeded);
    }

    public void minusResources(int waterNeeded, int milkNeeded, int beansNeeded) {
        water -= waterNeeded;
        milk -= milkNeeded;
        beans -= beansNeeded;
    }
}