package mypackage;

public class CoffeeEspresso extends Coffee {

	public CoffeeEspresso() {
		super(100, 100, 50, 2.50);
	}

	@Override
	public String getCoffeeName() {
		return "Espresso";

	}

}
