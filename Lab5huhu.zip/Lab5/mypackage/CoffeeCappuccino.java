package mypackage;

public class CoffeeCappuccino extends Coffee {

	public CoffeeCappuccino() {
		super(100, 100, 50, 2.50);
	}

	@Override
	public String getCoffeeName() {
		return "Cappucino";

	}

}
